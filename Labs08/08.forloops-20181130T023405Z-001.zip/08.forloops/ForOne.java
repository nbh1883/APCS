//(c) A+ Computer Science
// www.apluscompsci.com

//for loop example 1

import static java.lang.System.*;

public class ForOne
{
	public static void main(String args[])
	{
	           //Start	  Stop      Increment
		for(int  aplus=1;   aplus<=20;   aplus=aplus+2)
		{
		   out.println(aplus);
		}
	}
}
