//(c) A+ Computer Science
// www.apluscompsci.com

//for each loop example

import static java.lang.System.*;

public class NewFor
{
	public static void main(String args[])
	{
		String s = "apluscompsci";
		for(char c : s.toCharArray())
		{
		    out.println(c);
		}
	}
}
