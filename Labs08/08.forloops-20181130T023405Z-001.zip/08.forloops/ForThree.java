//(c) A+ Computer Science
// www.apluscompsci.com

//for loop example 3

import static java.lang.System.*;

public class ForThree
{
	public static void main(String args[])
	{
		for(int aplus=7; aplus>2; aplus-=2)	//change the stop and decrement
		{
		   out.println("aplus");
		   out.println( aplus );
		}
	}
}
