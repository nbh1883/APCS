//(c) A+ Computer Science
// www.apluscompsci.com

//a for loop and String example

import static java.lang.System.*;

public class ForStrings
{
	public static void main(String args[])
	{
		String s = "apluscompsci";
		for(int i=0; i<s.length(); i++)
		{
		    out.println(s.charAt(i));
		}
	}
}
