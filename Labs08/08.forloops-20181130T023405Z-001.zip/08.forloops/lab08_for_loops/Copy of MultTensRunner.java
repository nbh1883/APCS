//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import static java.lang.System.*; 

public class MultTensRunner
{
	public static void main( String[] args )
	{
		System.out.println( MultTens.go( 1 ) );
		System.out.println( MultTens.go( 2 ) );
		System.out.println( MultTens.go( 13 ) );
		System.out.println( MultTens.go( 4 ) );
		System.out.println( MultTens.go( 10 ) );
		System.out.println( MultTens.go( -5 ) );
		System.out.println( MultTens.go( 0 ) );
		System.out.println( MultTens.go( 6 ) );
	}
}