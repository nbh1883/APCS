//(c) A+ Computer Science
//www.apluscompsci.com
//Name

public class ForLoopDemoRunner
{
	public static void main ( String[] args )
	{
		ForLoopDemo.runForLoop(2,90,5);

		//add more test cases	
		
	}
}