//(c) A+ Computer Science
//www.apluscompsci.com
//Name

import static java.lang.System.*;

public class GCD {
	private int one, two;

	public GCD() {
	}

	public GCD(int numOne, int numTwo) {
	}

	public void setNums(int numOne, int numTwo) {
	}

	public long getGCD() {
		long gcd = 0;
		return 1;
	}

	public String toString() {
		return "";
	}
}