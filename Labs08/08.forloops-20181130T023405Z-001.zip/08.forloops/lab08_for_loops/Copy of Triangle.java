//(c) A+ Computer Science
//www.apluscompsci.com
//Name

import static java.lang.System.*;

public class Triangle
{
	private String word;

	public Triangle()
	{
		word="";
	}

	public Triangle(String s)
	{
	}


	public void setWord(String s)
	{
	}

	public void print( )
	{

	}
}