//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;



public class TriangleOneRunner
{
	public static void main ( String[] args )
	{
		
		TriangleOne triangle = new TriangleOne("hippo");
		
		
		
		triangle.print();
		
		triangle.setWord("abcd");
		triangle.print();
		
		triangle.setWord("it");
		triangle.print();
		
		triangle.setWord("a");
		triangle.print();
		
		triangle.setWord("chicken");
		triangle.print();
		
		
		
		
	
				
	}
}