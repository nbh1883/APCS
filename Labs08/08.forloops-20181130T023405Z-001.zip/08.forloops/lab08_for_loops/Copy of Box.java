//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class Box
{
	private String word;



	public Box()
	{
		word = "";	
	}



	public Box(String s)
	{
		setWord(s);
	} 


	public void setWord(String s)
	{
		word = s;		
	} 


	public void print( )
	{
		
		for (int length = 0;   length < word.length();  length++)
		{
			   System.out.println(word);
		}
		
		System.out.println();
		System.out.println();
		
	}
}