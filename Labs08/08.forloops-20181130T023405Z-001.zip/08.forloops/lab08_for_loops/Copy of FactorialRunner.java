//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;


public class FactorialRunner
{
	public static void main ( String[] args )
	{
		
		Factorial factor = new Factorial(5);
		

		
		out.println(factor);
		
		factor.setNum(4);
		out.println(factor);
		
		factor.setNum(8);
		out.println(factor);
		
		factor.setNum(15);
		out.println(factor);
		
		factor.setNum(6);
		out.println(factor);
		
		factor.setNum(9);
		out.println(factor);
		
		factor.setNum(3);
		out.println(factor);
		
		
		// add more cases
		
		
		
	}
}