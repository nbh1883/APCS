//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;



public class BoxRunner
{
	public static void main ( String[] args )
	{
		
		Box box = new Box("hippo");
		box.print();
		
		box.setWord("abcd");
		box.print();
		
		box.setWord("it");
		box.print();
		
		box.setWord("a");
		box.print();
		
		box.setWord("chicken");
		box.print();
	}
}